package com.spring.carwash.PurchaseAddOnService.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.spring.carwash.PurchaseAddOnService.model.PurchaseAddPojo;

@Repository
public interface PurchaseAddRepository extends MongoRepository<PurchaseAddPojo, String> {

}
