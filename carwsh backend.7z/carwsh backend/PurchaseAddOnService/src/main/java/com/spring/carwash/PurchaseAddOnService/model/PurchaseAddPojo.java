package com.spring.carwash.PurchaseAddOnService.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="addpurchasecollection")
public class PurchaseAddPojo {

	@Id
	String email;
	String typeOfVechile;
	String partOfDay;
	String dirtyVechile;
	
	public PurchaseAddPojo() {
		super();
		
	}

	public PurchaseAddPojo(String email, String typeOfVechile, String partOfDay, String dirtyVechile) {
		super();
		this.email = email;
		this.typeOfVechile = typeOfVechile;
		this.partOfDay = partOfDay;
		this.dirtyVechile = dirtyVechile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTypeOfVechile() {
		return typeOfVechile;
	}

	public void setTypeOfVechile(String typeOfVechile) {
		this.typeOfVechile = typeOfVechile;
	}

	public String getPartOfDay() {
		return partOfDay;
	}

	public void setPartOfDay(String partOfDay) {
		this.partOfDay = partOfDay;
	}

	public String getDirtyVechile() {
		return dirtyVechile;
	}

	public void setDirtyVechile(String dirtyVechile) {
		this.dirtyVechile = dirtyVechile;
	}

	@Override
	public String toString() {
		return "PurchaseAddPojo [email=" + email + ", typeOfVechile=" + typeOfVechile + ", partOfDay=" + partOfDay
				+ ", dirtyVechile=" + dirtyVechile + "]";
	}
	
	
}
